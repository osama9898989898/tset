import React from 'react';
// import { Head } from '@inertiajs/inertia-react';

export default function Test() {
    return (
        <div>
            
            <h1>Welcome</h1>
            <a href='/wscos'>wscos</a>
        </div>
        
    )
} 
